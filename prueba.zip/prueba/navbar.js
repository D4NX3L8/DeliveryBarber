import { getCurrentUser } from "../../../src/controllers/user-controller.js";

const navbar = document.getElementById("navbar");
const user = getCurrentUser();

// Función global para alternar temas y guardar preferencia
window.toggleTheme = function () {
    const body = document.body;
    const logo = document.getElementById("mainLogo");
    const isDark = body.getAttribute('data-theme') === 'dark';
    const newTheme = isDark ? '' : 'dark';

    body.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);

    if (logo) {
        logo.src = isDark
            ? "/DeliveryBarber/public/images/modo normal.png"
            : "/DeliveryBarber/public/images/modo oscuro.png";
    }
};

// Aplicar el tema guardado al cargar la página
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    document.body.setAttribute('data-theme', 'dark');
}

// Función para generar el HTML del navbar
const getNavbarContent = (links, actions) => {
    const isDark = localStorage.getItem('theme') === 'dark';
    const logoSrc = isDark ? "/DeliveryBarber/public/images/modo oscuro.png" : "/DeliveryBarber/public/images/modo normal.png";
    
    return `
    <header class="navbar">
        <div class="container">
            <a href="../public/home.html" class="logo">
                <img src="${logoSrc}" alt="Logo" id="mainLogo">
                <h1>Delivery Barber</h1>
            </a>
            <nav class="nav-links">
                <ul>${links}</ul>
            </nav>
            <div class="nav-actions">
                <button class="theme-toggle" onclick="toggleTheme()">Modo</button>
                ${actions}
            </div>
            <button class="menu-toggle">
                <span></span><span></span><span></span>
            </button>
        </div>
    </header>`;
};

// Lógica de renderizado según el rol
if (!user || Object.keys(user).length === 0) {
    navbar.innerHTML = getNavbarContent(
        `<li><a href="../public/home.html">Inicio</a></li>
         <li><a href="../public/services.html">Servicios</a></li>
         <li><a href="../public/products.html">Productos</a></li>
         <li><a href="../public/gallery.html">Galería</a></li>
         <li><a href="../public/contact.html">Contacto</a></li>`,
        `<a href="../auth/login.html">Login</a><a href="../auth/register.html">Registro</a>`
    );
} else if (user.role === "client") {
    navbar.innerHTML = getNavbarContent(
        `<li><a href="../client/home.html">Inicio</a></li>
         <li><a href="../client/reservations.html">Reservar</a></li>
         <li><a href="../client/myAppointments.html">Mis citas</a></li>
         <li><a href="../public/products.html">Productos</a></li>`,
        `<a href="../client/profile.html">Mi perfil</a><a href="../auth/logout.html">Salir</a>`
    );
} else if (user.role === "admin") {
    navbar.innerHTML = getNavbarContent(
        `<li><a href="../admin/dashboard.html">Dashboard</a></li>
         <li><a href="../admin/users.html">Usuarios</a></li>
         <li><a href="../admin/barbers.html">Barberos</a></li>
         <li><a href="../admin/services.html">Servicios</a></li>
         <li><a href="../admin/products.html">Productos</a></li>
         <li><a href="../admin/reservations.html">Reservas</a></li>`,
        `<a href="../admin/profile.html">Mi perfil</a><a href="../auth/logout.html">Salir</a>`
    );
} else if (user.role === "barber") {
    navbar.innerHTML = getNavbarContent(
        `<li><a href="../barber/dashboard.html">Dashboard</a></li>
         <li><a href="../barber/appointments.html">Agenda</a></li>
         <li><a href="../barber/clients.html">Clientes</a></li>
         <li><a href="../barber/services.html">Servicios</a></li>`,
        `<a href="../barber/profile.html">Mi perfil</a><a href="../auth/logout.html">Salir</a>`
    );
}